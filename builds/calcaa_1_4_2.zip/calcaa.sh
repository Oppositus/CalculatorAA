#!/usr/bin/env bash

java -jar calcaa.jar
